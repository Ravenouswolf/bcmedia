package com.bc.bcmedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcmediaApplicationTests {

    @Test
    void contextLoads() {
    }

}
