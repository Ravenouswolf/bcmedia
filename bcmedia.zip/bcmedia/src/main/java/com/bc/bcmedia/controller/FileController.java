package com.bc.bcmedia.controller;

import com.bc.bcmedia.entity.Data;
import org.springframework.web.bind.annotation.*;

import java.io.*;

@RestController
@RequestMapping("/file")
public class FileController {
    @PostMapping("/write")
    public String write(@RequestBody Data data){
            String proxy="";
            switch (data.getProxy()){
                case "1":
                    proxy = "广告主代理";
                    break;
                case "2":
                    proxy = "媒体主代理";
            }
            String username = data.getUsername();
            String usertel = data.getUsertel();
            String usercompany = data.getUsercompany();
            String text = proxy+","+username+","+usertel+","+usercompany+"\n";
        System.out.println(text);
        Writer writer = null;
        try {
            String path = "src//main//resources//static//data.csv";
            writer = new FileWriter(path,true);
            writer.write(text);
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return "success";
    }

}
