package com.bc.bcmedia.entity;
@lombok.Data
public class Data {
    private String proxy;
    private String username;
    private String usertel;
    private String usercompany;
}
