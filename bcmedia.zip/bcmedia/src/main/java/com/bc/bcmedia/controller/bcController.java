package com.bc.bcmedia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/bc")
public class bcController {

    @GetMapping("/merchants")
    public String merchants(){
        return "merchantsPC";
    }
    @GetMapping("/join")
    public String join(){
        return "joinPC";
    }
    @GetMapping("/merchantsMobile")
    public String merchantsMobile(){
        return "merchantsMobile";
    }
    @GetMapping("/joinMobile")
    public String joinMobile(){
        return "joinMobile";
    }
}
