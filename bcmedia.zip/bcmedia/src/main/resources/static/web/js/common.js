// function msg(text, obj, tipsMore = true) {
//     $(obj).focus();
//     layer.tips(text, obj, {tipsMore: tipsMore});
// }

$(function () {
    var navLi = $('.js_navlist>li');
    var navOl = $('.js_navlist ol');
    navLi.hover(function () {
        navOl.hide();
        $(this).find('ol').stop().fadeIn();
    }, function () {
        navOl.hide();
    });
    /*header.mouseleave(function () {
        navOl.hide();
    });*/
    var agent = $('#agent');
    var agentBtn = $('.js_agentBtn');
    agentBtn.click(function () {
        agent.fadeIn();
    });
    agent.click(function (e) {
        if (e.target == this) {
            agent.hide();
        }
    });
    $(".agent_closeBtn").click(function () {
        agent.hide();
    })

    $('.proxy_type').click(function () {
        if (!$(this).find('i').hasClass('cur')) {
            $('.proxy_type i').removeClass('cur');
            $(this).find('i').addClass('cur');
        }
    });
    // $('#submit_apply').click(function () {
    //     var proxy = 1;
    //     if ($('#j_media_proxy i').hasClass('cur')) {
    //         proxy = 2;
    //     }
    //     var user_name = $.trim($('#user_name').val());
    //     var user_tel = $.trim($('#user_tel').val());
    //     var user_company = $.trim($('#user_company').val());
    //     if (user_name.length <= 0) {
    //         msg('请输入您的称呼', '#user_name', false);
    //         return false;
    //     } else if (user_tel.length <= 0) {
    //         msg('请输入您的手机号', '#user_tel', false);
    //         return false;
    //     } else if (user_company.length <= 0) {
    //         msg('请输入您的公司名称', '#user_company', false);
    //         return false;
    //     }
    //     var data = {
    //         proxy: proxy,
    //         username: user_name,
    //         usertel: user_tel,
    //         usercompany: user_company
    //     }
    //     $.ajax({
    //         type: 'post',
    //         url: '/file/write',
    //         contentType : "application/json;charset=utf-8",
    //         dataType:"json",
    //         data : JSON.stringify(data),
    //         success : function(msg) {
    //             alert(msg);
    //             if(msg){
    //                 window.location.href = "http://localhost:8080/bc/join";
    //             }
    //         }
    //     })
    // });
});
